package conexao;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.SwingUtilities;

import trabrestaurante.Carrinho;

public class ClienteConexao {
    private static final String IP_SERVIDOR = "10.104.0.4"; // IP da máquina do servidor
    private static final int PORTA = 5000;

    public static void main(String[] args) {
        try (Socket socket = new Socket(IP_SERVIDOR, PORTA)) {
            System.out.println("Conectado ao servidor!");

            // Exemplo de envio de mensagem
            OutputStream output = socket.getOutputStream();
            PrintWriter writer = new PrintWriter(output, true);
            writer.println("Olá, servidor! Aqui é o cliente.");

            // Abrir interface gráfica do cardápio (Carrinho)
            abrirInterfaceCarrinho();

        } catch (IOException e) {
            System.err.println("Erro ao conectar no servidor: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void abrirInterfaceCarrinho() {
        SwingUtilities.invokeLater(() -> {
            Carrinho carrinho = new Carrinho();
            carrinho.setVisible(true);
        });
    }
}