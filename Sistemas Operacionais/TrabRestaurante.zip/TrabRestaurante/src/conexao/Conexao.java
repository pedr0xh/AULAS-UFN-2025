/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author laboratorio
 */
public class Conexao {

    public static Connection conectar() {
        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://10.104.0.4:3306/SistemaPedidos?useTimezone=true&serverTimezone=UTC",
                "root", 
                "laboratorio"
            );
            System.out.println("Conexão realizada com sucesso!");
            return conn;
        } catch (SQLException e) {
            System.out.println("Erro ao conectar no banco de dados: " + e.getMessage());
            return null;
        }
    }
}
